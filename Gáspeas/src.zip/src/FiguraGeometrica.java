
public class FiguraGeometrica {
		
}
